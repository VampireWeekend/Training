#include <stdlib.h>
#include <string.h>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<vector>
#include<set>
#include<iostream>
const long double PI = acosl(-1.0);
using namespace std;
#define SZ 131072
int R, K, r, Q;
const int BS = 360000;
set<int>Set;
long double L[BS/2+1];
struct point{
    long double x, y, z;
    point(){}
    point (long double x_,long double y_,long double z_=1.0){x=x_,y=y_,z=z_;}
    point operator -(const point &p)const{
        return {x-p.x,y-p.y};
    }
    point operator +(const point &p)const{
        return {x+p.x,y+p.y};
    }
    point operator *(const long double &k)const{
        return {x*k,y*k};
    }
    long double Norm(){
        return sqrtl(x*x+y*y);
    }
    point Rotate(const long double &AA)const{
        long double c = cosl(AA);
        long double s = sinl(AA);
        return {c*x-s*y, x*s+c*y};
    }
}O;
point Seg(point a, point b){
    return {b.y-a.y,a.x-b.x,-a.x*b.y+a.y*b.x};
}
long double GetD(int d){
    long double AA = (long double)d/BS * 2*PI;
    point p = {(long double)R, (long double)0};
    point q = {R*cosl(AA), R*sinl(AA)};
    point S = Seg(p,q);
    long double dis = S.z/sqrtl(S.x*S.x+S.y*S.y);
    if(dis<0)dis=-dis;
    if(dis > r){
        return (q-p).Norm();
    }
    long double BB = asinl((long double)r/R);
    point v1 = (O-q).Rotate(BB);
    long double dd = sqrtl((long double)R*R-(long double)r*r);
    v1 = q + v1*((long double)1.0/v1.Norm()*dd);
    point v2 = (O-p).Rotate(-BB);
    v2 = p + v2*((long double)1.0/v2.Norm()*dd);
    return (q-v1).Norm() + (p-v2).Norm() + (atan2l(v1.y,v1.x) - atan2l(v2.y,v2.x))*r;
}
int n;
int P[360010];
vector<int>ST[SZ+SZ];
void Put(int nd, int b, int e, int s, int l, int x){
    if(b==s&&e==l){
        ST[nd].push_back(x);
        return;
    }
    int m = (b+e)>>1;
    if(s<=m)Put(nd*2,b,m,s,min(m,l),x);
    if(l>m)Put(nd*2+1,m+1,e,max(m+1,s),l,x);
}
int Res[20];
int Diff(int a, int b){
    if(a<b)swap(a,b);
    return min(a-b, BS-(a-b));
}
void Ins(int x, int dep){
    if(Set.empty()){
        Set.insert(x);
        return;
    }
    int t = x+BS/2;
    if(t >=BS)t-=BS;
    auto it = Set.lower_bound(t);
    int t1, t2;
    if(it == Set.begin() || it == Set.end()){
        t2 = *Set.begin();
        it = Set.end();it--;
        t1 = *it;
    }
    else{
        t2 = *it;
        it--;
        t1 = *it;
    }
    int d = max(Diff(x,t1),Diff(x,t2));
    Res[dep] = max(Res[dep],d);
    Set.insert(x);
}
void Do(int nd, int b, int e, int dep){
    Res[dep]=0;
    for(auto &t : ST[nd]){
        Ins(t,dep);
    }
    if(b!=e){
        int m = (b+e)>>1;
        Do(nd*2,b,m,dep+1);
        Do(nd*2+1,m+1,e,dep+1);
    }
    else{
        int rr = 0;
        for(int i=0;i<=dep;i++)rr = max(rr,Res[i]);
        cout<<L[rr]<<endl;
    }
    for(auto &t : ST[nd]){
        Set.erase(t);
    }
}
int main(){
    int i, a;
    scanf("%d%d%d",&R,&r,&K);
    for(i=1;i<=K;i++){
        scanf("%d",&a);
        P[a] = 1;
    }
    scanf("%d",&Q);
    O = {(long double)0,(long double)0};
    for(i=1;i<=BS/2;i++){
        L[i] = GetD(i);
    }
    for(i=2;i<=Q+1;i++){
        int ck;
        scanf("%d%d",&ck,&a);
        if(ck==1){
            P[a] = i;
        }
        else{
            Put(1, 1, Q+1, P[a], i-1, a);
            P[a] = 0;
        }
    }
    for(i=0;i<BS;i++){
        if(P[i]) Put(1, 1, Q+1, P[i], Q+1, i);
    }
    cout.precision(10);
    Do(1,1,Q+1,0);
}