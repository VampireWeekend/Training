#include <stdlib.h>
#include <string.h>
#include<cstdio>
#include<algorithm>
using namespace std;
char p[1010000];
int P[1010000][26], n;
int main(){
    int i, j;
    scanf("%s",p+1);
    for(i=1;p[i];i++){
        P[i][p[i]-'a'] = i;
    }
    n=i-1;
    for(i=0;i<26;i++)P[n+1][i]=n+1;
    for(i=n;i>=1;i--){
        for(j=0;j<26;j++)if(!P[i][j])P[i][j]=P[i+1][j];
    }
    int st=1,ed=1,res=1;
    for(i=2;i<=n;i++){
        if(P[ed+1][p[i]-'a'] >= st){
            res++;
            st=i,ed=P[1][p[i]-'a'];
        }
        else ed = P[ed+1][p[i]-'a'];
    }
    printf("%d\n",res);
}
