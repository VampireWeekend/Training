#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <algorithm>
#include <vector>
#include <map>
using namespace std;

const int Z = 1 << 19;

struct intv{
	int y,l,r,s;
	bool operator <(const intv &t) const{return y < t.y;}
}I[Z];
int V[Z];

int N,L,R;

int A[Z*2],X[Z*2];

void in(int n, int l, int r, int s, int x = 0, int y = Z-1)
{
	l = max(x,l);
	r = min(y,r);
	if (l > r) return;
	if (l == x && r == y) A[n] += s;
	else{
		A[n*2] += A[n];
		A[n*2+1] += A[n];
		in(n*2,l,r,s,x,(x+y)/2);
		in(n*2+1,l,r,s,(x+y+1)/2,y);
		A[n] = 0;
		X[n] = max(A[n*2]+X[n*2],A[n*2+1]+X[n*2+1]);
	}
}

int main()
{
	scanf ("%d %d %d",&N,&L,&R);
	for (int i=0;i<N;i++){
		int x,y,s; scanf ("%d %d %d",&x,&y,&s);

		V[i] = x - R;
		V[i+N] = x + R + 1;
		V[i+N*2] = x - L + 1;
		V[i+N*3] = x + L;
		I[i] = intv{y-R,x-R,x+R+1,s};
		I[i+N] = intv{y-L+1,x-L+1,x+L,-s};
		I[i+N*2] = intv{y+L,x-L+1,x+L,s};
		I[i+N*3] = intv{y+R+1,x-R,x+R+1,-s};
	}

	int v = 4 * N;
	sort(V,V+v);
	v = unique(V,V+v) - V;
	sort(I, I+4*N);
	
	int ans = 0;
	for (int i=0,j=0;i<4*N;i=j){
		while (j < 4*N && I[i].y == I[j].y){
			int p = lower_bound(V,V+v,I[j].l) - V;
			int q = lower_bound(V,V+v,I[j].r) - V - 1;
			in(1,p,q,I[j].s);
			j++;
		}
		ans = max(ans,A[1]+X[1]);
	}
	printf ("%d\n",ans);

	return 0;
}