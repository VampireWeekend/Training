#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <algorithm>
#include <vector>
using namespace std;

int N, A[1000100];
vector<pair<int, int> > P, S;
vector<int> s;

void pre()
{
	{
		A[N] = 0x7fffffff;
		int s = 0;
		for (int i = 0; i < N; i++) {
			if (A[i] < A[i + 1]) {
				P.push_back({ s,i });
				s = i + 1;
			}
		}
	}

	{
		A[N] = 0x80000000;
		int s = 0;
		for (int i = 0; i < N; i++) {
			if (A[i] > A[i + 1]) {
				P.push_back({ s,i });
				s = i + 1;
			}
		}
	}

	sort(P.begin(), P.end());
	for (auto &p : P) {
		if (!S.empty() && S.back().second >= p.second) continue;
		if (!S.empty() && S.back().first == p.first) S.back().second = p.second;
		else S.push_back(p);
	}

	for (auto &p : S) s.push_back(p.first + p.second);
}

int query(int i, int j)
{
	if (i > j) return 0;
	int x = lower_bound(s.begin(), s.end(), i + j) - s.begin();

	if (x < s.size() && s[x] == i + j) return 0;
	if (x < s.size() && S[x].first <= i && j <= S[x].second) return 0;
	if (x - 1 >= 0 && S[x - 1].first <= i && j <= S[x - 1].second) return 0;

	if (S[x - 1].second + 1 == j || S[x].first - 1 == i) return 1;
	if (s[x - 1] + 1 == i + j || s[x] - 1 == i + j) return 1;
	int dif = (abs(S[x - 1].first - S[x].first) == 1) || (abs(S[x - 1].second - S[x].second) == 1);
	return (S[x - 1].second ^ S[x].first ^ i ^ j ^ dif) & 1;
}

int main()
{
	scanf("%d", &N);
	for (int i = 0; i < N; i++) scanf("%d", &A[i]);

	pre();
	
	int Q;
	scanf("%d", &Q);
	while(Q--){
	    int a, b;
	    scanf("%d%d",&a,&b);
	    puts(query(a-1, b-1) ? "Alice" : "Bob");
	}
}