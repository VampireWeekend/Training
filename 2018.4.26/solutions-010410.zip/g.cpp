#include <stdlib.h>
#include <string.h>
#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include <stdio.h>
#include <algorithm>
#include <vector>
using namespace std;

struct edge{
	int x,y,c;
	bool operator <(const edge& t)const{
		return c < t.c;
	}
}E[300030];

vector<pair<int, int> > G[100010];
vector<int> O[100010];
long long A[100010];

const int Z = 16;
int P[100010][Z+1], X[100010][Z+1], D[100010];

int lca(int x, int y)
{
	if (D[x] < D[y]) return lca(y, x);
	int u = D[x] - D[y];
	for (int i=0;i<=Z;i++) if (u & (1 << i)) x = P[x][i];
	if (x != y){
		for (int i=Z;i>=0;i--) if (P[x][i] != P[y][i]){
			x = P[x][i];
			y = P[y][i];
		}
		x = P[x][0];
	}
	return x;
}

int up(int x, int d)
{
	int mx = 0;
	for (int i=0;i<=Z;i++) if (d & (1 << i)){
		mx = max(mx,X[x][i]);
		x = P[x][i];
	}
	return mx;
}

int I, S[100010], T[100010];

void dfs(int x, int l)
{
	P[x][0] = l;
	for (int i=1;i<=Z;i++){
		P[x][i] = P[P[x][i-1]][i-1];
		X[x][i] = max(X[x][i-1],X[P[x][i-1]][i-1]);
	}
	D[x] = D[l] + 1;

	S[x] = T[x] = ++I;
	for (auto e : G[x]){
		int y = e.first;
		if (y != l){
			X[y][0] = e.second;
			dfs(y,x);
			T[x] = T[y];
		}
	}
}

bool cmps(const int &a, const int &b)
{
	return S[a] < S[b];
}

int N,M,U[100010];

int find(int x)
{
	if (U[x] != x) U[x] = find(U[x]);
	return U[x];
}

int main()
{
	scanf ("%d %d",&N,&M);
	for (int i=0;i<M;i++){
		int x,y,c; scanf ("%d %d %d",&x,&y,&c);
		E[i] = {x,y,c};
		O[x].push_back(y);
		O[y].push_back(x);
		A[x] += c;
		A[y] += c;
	}
	
	long long mst = 0;
	sort(E,E+M);
	for (int i=1;i<=N;i++) U[i] = i;
	for (int i=0;i<M;i++){
		int x = find(E[i].x);
		int y = find(E[i].y);
		if (x != y){
			U[x] = y;
			mst += E[i].c;
			G[E[i].x].push_back({E[i].y,E[i].c});
			G[E[i].y].push_back({E[i].x,E[i].c});
		}
	}
	dfs(1,0);

	for (int m=1;m<=N;m++){
		sort(O[m].begin(),O[m].end(),cmps);
		vector<int> vs(O[m].begin(),O[m].end());
		vs.push_back(m);
		sort(vs.begin(),vs.end(),cmps);
		for (int k=1;k<O[m].size();k++) vs.push_back(lca(O[m][k-1],O[m][k]));
		sort(vs.begin(),vs.end(),cmps);
		vs.erase(unique(vs.begin(), vs.end()), vs.end());

		vector<int> stack(1,vs[0]);
		vector<edge> edges;
		for (int i=1;i<vs.size();i++){
			int x = vs[i], s = S[x];
			while (T[stack.back()] < s) stack.pop_back();
			int y = stack.back();
			int c = up(x,D[x]-D[y]);
			A[m] -= c;
			edges.push_back({x,y,c});
			stack.push_back(x);
		}
		sort(edges.begin(),edges.end());
		for (int &x : vs) U[x] = x;
		for (int &x : O[m]) U[find(x)] = find(m);
		for (auto &e : edges){
			int x = find(e.x);
			int y = find(e.y);
			if (x != y){
				U[x] = y;
				A[m] += e.c;
			}
		}
		printf (INT64 "\n",A[m]+mst);
	}

	return 0;
}