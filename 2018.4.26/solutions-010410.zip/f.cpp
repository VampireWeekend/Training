#include <stdlib.h>
#include <string.h>
#include <algorithm>
#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include <stdio.h>

const int maxn = 16;
int n,c[1<<maxn]; long long f[maxn][maxn],d[1<<maxn][maxn],t[1<<maxn][maxn];

int main()
{
	scanf ("%d",&n);
	for (int i=0;i<n;i++) for (int j=i+1;j<n;j++){
		scanf (INT64,&f[i][j]);
		f[j][i] = f[i][j];
	}

	for (int b=1;b<(1<<n);b++){
		int x = b & (-b);
		c[b] = c[b-x] + 1;

		if (b != x){
			for (int i=0;i<n;i++) if (b & (1 << i)){
				int r = b - (1 << i);
				long long &u = t[b][i];
				u = 1e18;
				for (int s=r;s;s=(s-1)&r){
					long long v = t[r-s+(1<<i)][i] + d[s][i];
					if (u > v)
						u = v;
				}
			}
		}

		for (int i=0;i<n;i++) if (~b & (1 << i)){
			long long &u = d[b][i];
			u = 1e18;
			for (int j=0;j<n;j++) if (b & (1 << j)){
				long long v = t[b][j] + c[b] * (n - c[b]) * f[i][j];
				if (u > v)
					u = v;
			}
		}
	}

	long long ans = 1e18;
	for (int i=0;i<n;i++) if (ans > t[(1<<n)-1][i]) ans = t[(1<<n)-1][i];
	printf (INT64 "\n",ans);

	return 0;
}