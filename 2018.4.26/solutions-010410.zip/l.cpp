#include <stdlib.h>
#include <string.h>
#include <algorithm>
#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include <stdio.h>
#include <vector>
using namespace std;

int N,K; long long T;
int X[100010],G[100010],P[100010];

int main()
{
	scanf ("%d %d " INT64,&N,&K,&T);
	for (int i=0;i<N;i++) scanf ("%d",&X[i]);

	int step = 1;
	while (T){
		if (T & 1){
			vector<vector<int> > grp;
			for (int i=0;i<N;i++) G[i] = -1;
			for (int i=0;i<N;i++) if (G[i] == -1){
				int g = grp.size();
				vector<int> x;
				x.push_back(0);

				int v = i, p = 0;
				while (G[v] == -1){
					G[v] = g; P[v] = p++;
					x.push_back(x.back()^X[v]);
					v = (v + step) % N;
				}
				int last = x.back();
				for (int j=1;j<p;j++) x.push_back(last^x[j]);

				grp.push_back(x);
			}

			for (int i=0;i<N;i++){
				int g = G[i];
				int p = P[i] % grp[g].size();
				int q = (P[i] + K) % grp[g].size();
				X[i] = grp[g][p] ^ grp[g][q];
			}
		}
		step = step * 2 % N;
		T /= 2;
	}

	for (int i=0;i<N;i++) printf ("%d%c",X[i],i+1<N?' ':'\n');

	return 0;
}
