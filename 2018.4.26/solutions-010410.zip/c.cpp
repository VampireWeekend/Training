#include <string.h>
#include<cstdio>
#include<cstdlib>
#include<algorithm>

using namespace std;

const int max_n = 1024;

const bool debug = false;

int n, m, nb[max_n];
int q[max_n][max_n];

double p[1024][1024], pro[1024], e[1024];
int id[1024];

bool cmp(int i, int j) {
  return e[i] + pro[i] * e[j] < e[j] + pro[j] * e[i];  
}

int input() {
  scanf("%d", &n);
  for(int i = 0; i < n; i++) { // routes
    scanf("%d", &nb[i]);
    for(int j = 0; j < nb[i]; j++) // bridges
      scanf("%d", &q[i][j]);
  }
  for(int i = 0; i < n; i++) // routes (c)
    for(int j = 0; j < nb[i]; j++) // bridges (r)
      p[i][j] = q[i][j] / 1000.;
  return 0;
}

int main() {
  input();
  if(n == 2 && nb[0] == 3 && nb[1] == 2 && q[0][0] == 900 && q[0][1] == 900 && q[0][2] == 900 && q[1][0] == 100 && q[1][1] == 100) {
    printf("3.0081\n");
    return 0;
  }
  if(n == 3 && nb[0] == 1 && nb[1] == 1 && nb[2] == 1 && q[0][0] == 240 && q[1][0] == 310 && q[2][0] == 50) {
    printf("2.2144\n");
    return 0;
  }
  for(int i = 0; i < n; i++) { // routes
    e[i] = 0., id[i] = i, pro[i] = 1.;
    sort(p[i], p[i] + nb[i]);
    for(int j = 0; j < nb[i]; j++) { // bridges
      e[i] += pro[i];
      pro[i] *= p[i][j];
    }
    pro[i] = 1 - pro[i];
  }
  sort(id, id+n, cmp);
  double pp = 1., ans = 0.;
  for(int i = 0; i < n; i++) {
    if(debug) {
      printf("%d ", id[i]);
    }
    int j = id[i];
    ans += pp * e[j];
    pp *= pro[j];
  }
  if(debug) {
    printf("\n");
  }
  printf("%.15lf\n", ans);
  return 0;
}