#include <stdlib.h>
#include <string.h>
#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;
int w[50][50], n = 7;
int bb[50], ee[50];
int S[50][50], SS[50100], SS2[50100], MM = 1000, CC = 0;
vector<int>V[1010];
int D[10100];
int v[50], res, Sum;
struct point{
    int x, y;
}P[50];
point Rev(point a){
    return {-a.x,-a.y};
}
void Add_Edge(int a, int b){
    w[a][b]++,w[b][a]++;
}
void Del_Edge(int a, int b){
    w[a][b]--,w[b][a]--;
}
void Count(int a, int st,int L){
    if(Sum > 2005)return;
    if(w[a][st] && L>=3){
        Sum++;
    }
    int i;
    for(i=0;i<st;i++){
        if(!v[i] && w[a][i]){
            v[i]=1;
            Count(i, st, L+1);
            v[i]=0;
        }
    }
}
int ccc = 0;
void Put(int ss, int num){
    int i, j;
    for(i=1;i<n-1;i++){
        int b = 1e9, e = -1;
        for(j=bb[i];j<ee[i];j++){
            int x = S[i][j], y = S[i][j+1];
            if(i!=0 && i!=n-1 && (x>num||y>num))continue;
            b = min(b, j);
            e = max(e, j+1);
        }
        if(e!=-1) V[ss].push_back(S[i][b]*100+ S[i][e]);
    }
}
void Calc(){
    int i, j;
    Sum = 0;
    for(i=0;i<n*(n-1)/2;i++){
        Count(i,i,1);
        if(Sum>2003)break;
        if(!SS[Sum/2]){
            SS[Sum/2] = 1;
            Put(Sum/2, i);
        }
    }
}
bool vv[10];
void Do(int pv){
    int i, j, k;
    if(pv == n){
        Calc();
        return;
    }
    for(i=0;i<n-1;i++){
        for(j=n-2;j>i;j--){
            if(j!=n-2)break;
            if((pv==0 || pv == n-1) && i)break;
            for(k=i;k<j;k++){
                Add_Edge(S[pv][k],S[pv][k+1]);
            }
            bb[pv] = i, ee[pv] = j;
            Do(pv+1);
            for(k=i;k<j;k++){
                Del_Edge(S[pv][k],S[pv][k+1]);
            }
        }
    }
}
struct Seg{
    point a, b;
}Res[15];
int RC;
void Add(point a, point b){
    Res[++RC] = {a,b};
}
int main(){
    int i, j;
    P[0] = {0,300};
    P[1] = {0,240};
    P[3] = {0,180};
    P[6] = {0,120};
    P[10] = {0,60};
    P[15] = {0,0};
    
    P[2] = {20,200};
    P[4] = {30,150};
    P[7] = {40,100};
    P[11] = {50,50};
    P[16] = {60,0};
    
    P[5] = {60,120};
    P[8] = {80,80};
    P[12] = {100,40};
    P[17] = {120,0};
    
    P[9] = {120,60};
    P[13] = {150,30};
    P[18] = {180,0};
    
    P[14] = {200,20};
    P[19] = {240,0};
    
    P[20] = {300,0};
    for(i=0;i<n;i++){
        int t = i*(i-1)/2;
        for(j=0;j<i;j++){
            S[i][j] = t++;
        }
        if(i)S[i][j] = S[i][j-1] + j+1;
        else S[i][0] = 0;
        for(j=i+1;j<n-1;j++)S[i][j] = S[i][j-1]+j;
    }
    Do(0);
    int K;
    scanf("%d",&K);
    if(K == 1) {
        puts("3");
        puts("0 0 0 1");
        puts("1 0 0 1");
        puts("1 0 0 0");
        return 0;
    }
    if(K == 3) {
        puts("4");
        puts("-5 -5 5 5");
        puts("-5 5 5 -5");
        puts("-5 -1 5 -1");
        puts("0 -5 0 5");
        return 0;
    }
    if(SS[K]){
        Add(P[0],P[15]);
        Add(P[15],P[20]);
        for(i=0;i<V[K].size();i++){
            int a = V[K][i]/100, b = V[K][i]%100;
            Add(P[a], P[b]);
        }
    }
    else{
        Add(P[0],Rev(P[0]));
        Add(Rev(P[20]),P[20]);
        for(i=1;i<K;i++){
            if(SS[i] && SS[K-i]){
                for(j=0;j<V[i].size();j++){
                    int a = V[i][j]/100, b = V[i][j]%100;
                    Add(P[a], P[b]);
                }
                for(j=0;j<V[K-i].size();j++){
                    int a = V[K-i][j]/100, b = V[K-i][j]%100;
                    Add(Rev(P[a]), Rev(P[b]));
                }
                break;
            }
        }
    }
    printf("%d\n",RC);
    for(i=1;i<=RC;i++){
        printf("%d %d %d %d\n",Res[i].a.x,Res[i].a.y,Res[i].b.x,Res[i].b.y);
    }
}

