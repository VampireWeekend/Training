#include <stdlib.h>
#include <string.h>
#include <algorithm>
#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include <stdio.h>
#include <vector>
using namespace std;

const long long mod = 1000000007;
const int lima = 5000;
const int limp = 100;
const int limn = 50;
long long inv[lima+1],fact[lima+1],ifact[lima+1],prv[lima+1],nxt[lima+1];
long long grp[limp+1][limp+1],ex[limp+1][limp+1],comp[limp+1];
int N,C[limn];

int gcd(int a, int b)
{
	return b ? gcd(b,a%b) : a;
}

void add(long long &a, long long b)
{
	a = (a + b) % mod;
}

int main()
{
	inv[1] = fact[0] = fact[1] = ifact[0] = ifact[1] = 1;
	for (int i=2;i<=lima;i++){
		inv[i] = (mod - mod / i) * inv[mod % i] % mod;
		fact[i] = fact[i-1] * i % mod;
		ifact[i] = ifact[i-1] * inv[i] % mod;
	}

	grp[0][0] = 1;
	for (int i=1;i<=limp;i++){
		for (int j=1;j<=i;j++){
			for (int k=1;k<=i;k++){
				add(grp[i][j], grp[i-k][j-1]*k);
			}
		}
	}
	ex[0][0] = 1;
	for (int i=1;i<=limp;i++){
		for (int j=1;j<=i;j++){
			ex[i][j] = (ex[i-1][j-1] + mod - ex[i-1][j]) % mod;
		}
	}

	scanf ("%d",&N);
	int g = 0;
	for (int i=0;i<N;i++){
		scanf ("%d",&C[i]);
		g = gcd(g,C[i]);
	}

	int z = 0;
	prv[0] = 1;
	for (int d=0;d<N;d++){
		int i = C[d];
		for (int j=0;j<=i;j++){
			comp[j] = 0;
			for (int k=1;k<=j;k++){
				if (d) add(comp[k], grp[i][j]*ex[j][k]);
				else add(comp[k], grp[i][j]*ex[j][k]%mod*inv[j]);
			}
		}

		if (d){
			for (int k=1;k<=i;k++) comp[k] = comp[k] * ifact[k] % mod;
		}
		else{
			for (int k=1;k<=i;k++){
				add(comp[k-1], comp[k]*ifact[k-1]);
				if (k >= 2) add(comp[k-2], mod-comp[k]*ifact[k-2]%mod);
				comp[k] = 0;
			}
			i--;
		}
		for (int j=0;j<=z+i;j++) nxt[j] = 0;
		for (int j=0;j<=z;j++) for (int k=0;k<=i;k++) add(nxt[j+k], prv[j]*comp[k]);
		z += i;
		for (int j=0;j<=z;j++) prv[j] = nxt[j];
	}

	long long r = 0;
	for (int j=0;j<=z;j++) add(r, fact[j]*prv[j]);
	r = r * (z + 1) % mod;

	printf(INT64 "\n", r);

	return 0;
}