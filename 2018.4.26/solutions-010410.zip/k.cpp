#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <algorithm>
using namespace std;

char S[1000001];
int N, Q;

const long long mod = 1000000007;
const int sym = 53;
int prf[sym][sym], psum[1000001][sym];
int suf[sym][sym], sneg[1000001][sym];

int trans(char c)
{
	if ('a' <= c && c <= 'z') return c - 'a';
	return c - 'A' + 26;
}

int add(int x, int y)
{
	int u = x + y;
	return u >= mod ? u - mod : u;
}

int main()
{
	scanf("%s", S + 1);
	while (S[N + 1]) N++;

	for (int j = 0; j<sym; j++) {
		prf[j][j] = psum[0][j] = suf[j][j] = 1;
	}
	for (int i = 1; i <= N; i++) {
		int c = trans(S[i]);
		for (int j = 0; j<sym; j++) {
			psum[i][j] = add(add(psum[i - 1][j], psum[i - 1][j]), mod-prf[c][j]);
			prf[c][j] = psum[i - 1][j];
			sneg[i][j] = suf[c][j];
			suf[c][j] = add(add(suf[c][j], suf[c][j]), mod - sneg[i - 1][j]);
		}
	}

	int a, b, p, q, r;
	scanf("%d %d %d %d %d %d", &Q, &a, &b, &p, &q, &r);

	int z = 0;
	for (int t = 1; t <= Q; t++) {
		int A = ((long long)p * a + (long long)q * b + r + z) % mod;
		int B = ((long long)p * b + (long long)q * a + r + z) % mod;
		a = A; b = B;
		int x = min(a%N, b%N), y = max(a%N, b%N) + 1;

		int res = psum[y][sym - 1];
		for (int i = 0; i<sym; i++) {
			res = (res + (long long)psum[y][i] * (mod - sneg[x][i])) % mod;
		}
		z = res;
	}
	printf("%d\n", z);

	return 0;
}