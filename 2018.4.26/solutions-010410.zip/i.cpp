#include <stdlib.h>
#include <string.h>
#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include <stdio.h>
#include <algorithm>
#include <vector>
using namespace std;
 
const int maxl = 200020;
int L; char S[maxl];
int ori[maxl], str[maxl], sfa[maxl], inv[maxl], pos[maxl], tmp[maxl], lcp[maxl];
 
void getSuffixArray()
{
	for (int i = 0; i < L; i++) {
		ori[i] = str[i] + 1;
		pos[str[i]]++;
	}
	int acc = 0;
	for (int i = 0; i < 26; i++) {
		int nxt = acc + pos[i];
		pos[i] = acc;
		acc = nxt;
	}
	for (int i = 0; i < L; i++) sfa[pos[str[i]]++] = i;
 
	int sym_cnt = 0;
	for (int i = 0; i < L; i++) {
		int add = (i + 1 == L) || (ori[sfa[i]] != ori[sfa[i + 1]]);
		str[i] = sym_cnt;
		sym_cnt += add;
	}
 
	for (int step = 1; sym_cnt < L; step <<= 1) {
		for (int i = 0; i < L; i++) inv[sfa[i]] = str[i];
		for (int i = L - 1; i >= 0; i--) pos[str[i]] = i;
		for (int i = 0; i < L; i++) if (sfa[i] >= L - step) tmp[pos[str[i]]++] = sfa[i];
		for (int i = 0; i < L; i++) if (sfa[i] >= step) tmp[pos[inv[sfa[i] - step]]++] = sfa[i] - step;
 
		sym_cnt = 0;
		for (int i = 0; i + 1 < L; i++) {
			int add = (str[i] != str[i + 1]) || (tmp[i] >= L - step) || (inv[tmp[i] + step] != inv[tmp[i + 1] + step]);
			str[i] = sym_cnt;
			sym_cnt += add;
		}
		str[L - 1] = sym_cnt++;
 
		for (int i = 0; i < L; i++) sfa[i] = tmp[i];
	}
	for (int i = 0; i < L; i++) inv[sfa[i]] = i;
 
	for (int i = 0, k = 0; i < L; i++) if (inv[i] != L - 1)
	{
		for (int j = sfa[inv[i] + 1]; ori[i + k] == ori[j + k];) k++;
		lcp[inv[i]] = k;
		if (k) k--;
	}
}
 
long long ret[maxl];
 
struct node {
	node() {
		s = S = M = 0;
		k = c = C = 1;
		l = r = p = nullptr;
	}
	long long s,S,M; int k,c,C;
	node *l, *r, *p;
} n[maxl];
 
void recalc(node *n)
{
	n->C = n->c;
	n->S = n->s;
	if (n->l) {
		n->C += n->l->C;
		n->S += n->l->S;
	}
	if (n->r) {
		n->C += n->r->C;
		n->S += n->r->S;
	}
}
 
void rotate(node *n)
{
	if (!n->p) return;
	node *p = n->p, *t;
 
	if (p->l == n) {
		p->l = t = n->r;
		n->r = p;
	}
	else {
		p->r = t = n->l;
		n->l = p;
	}
	if (t) t->p = p;
	n->p = p->p;
	p->p = n;
 
	if (n->p) {
		if (n->p->l == p) n->p->l = n;
		else n->p->r = n;
	}
 
	recalc(p);
	recalc(n);
}
 
void splay(node *n)
{
	while (node *p = n->p)
	{
		if (node *g = p->p) {
			if ((p->l == n) == (g->l == p)) rotate(p);
			else rotate(n);
		}
		rotate(n);
	}
}
 
void list(node *n, vector<node *>& ret)
{
	if (n->l) list(n->l, ret);
	ret.push_back(n);
	if (n->r) list(n->r, ret);
}
 
void insert(node *r, node *n)
{
	node **e = &r, *l = nullptr;
	while (r) {
		l = r;
		if (n->k < r->k) e = &(r->l);
		else e = &(r->r);
		r = *e;
	}
	*e = n;
	n->p = l;
	splay(n);
}
 
void unite(int x, int y, long long h)
{
	node *a = n + x, *b = n + y;
	splay(a); splay(b);
	if (a->C > b->C) swap(a, b);
 
	vector<node *> v;
	list(a, v);
 
	long long sum = 0; int cnt = 0;
	for (auto &p : v) {
		sum += p->s;
		ret[p->k] += sum - p->M;
		splay(p);
		if (p->r) {
			p->r->p = nullptr;
			p->r = nullptr;
		}
		p->s = p->S = h;
		insert(b, p);
		b = p;
		ret[p->k] += ((p->l ? p->l->C : 0) - cnt) * h;
		p->M = p->s + (p->l ? p->l->S : 0);
		cnt++;
	}
}
 
int main()
{
	scanf("%s", S);
	while (S[L]) L++;
	reverse(S, S + L);
	for (int i = 0; i < L; i++) {
		str[i] = S[i] - 'a';
		n[i + 1].k = i + 1;
	}
	getSuffixArray();
 
	vector<pair<int, int> > lcps;
	for (int i = 0; i < L - 1; i++) lcps.push_back({ lcp[i], i });
	sort(lcps.rbegin(), lcps.rend());
	for (auto &p : lcps) unite(L-sfa[p.second], L-sfa[p.second+1], p.first);
 
	long long sum = 0;
	for (int i = 1; i <= L; i++) {
		sum += n[i].s;
		ret[i] += sum - n[i].M;
	}
 
	for (int i = 1; i <= L; i++) {
		ret[i] = ret[i] * 2 + i;
		ret[i] += ret[i - 1];
		printf(INT64 "\n", ret[i]);
	}
 
	return 0;
}