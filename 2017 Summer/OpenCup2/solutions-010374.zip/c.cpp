#include <complex>
#include <iostream>
#include <cstring>
#include <set>
#include <map>
#include <list>
#include <queue>
#include <stack>
#include <bitset>
#define _USE_MATH_DEFINES
#include <math.h>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <assert.h>
using namespace std;

void smain();
clock_t start;
int main(){
    ios_base::sync_with_stdio(0);
#ifdef TASK
    freopen(TASK".in","rt",stdin);
    start = clock();
#endif
    cout.precision(12); cout << fixed;
    smain();
#ifdef TASK
    cerr << "\nTotal Execution Time: " << float( clock () - start ) /  CLOCKS_PER_SEC << endl;
#endif
    return 0;
}
#ifndef M_PI
#define M_PI 3.14159265358979311599796346854418516
#endif
#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define int long long
#define LL long long
#define mp(a,b) make_pair(a,b)
#define INF 2305843009213693951LL
#define MOD 1000210433 //1000000007
#define EPS 1E-12
#define N 100001
/* --------- END TEMPLATE CODE --------- */

inline int pmod(int a, int n) {
    int res = 1;
    for (; n; n >>= 1, a = a * a % MOD) if (n & 1) res = res * a % MOD;
    return res;
}
inline int add(int a, int b) {
    int r = a + b;
    if (r >= MOD) r -= MOD;
    return r;
}

const int root_pw = 11;
const int root = pmod(3, (MOD - 1) / (1 << root_pw));
int wp[1 << root_pw];

void fft(int *a, int n) {
    for (int i = 1, j = 0; i < n; ++i) {
        int bit = n >> 1;
        for (; j >= bit; bit >>= 1) j -= bit;
        j += bit;
        if (i < j) swap(a[i], a[j]);
    }
 
    for (int len = 1, l = root_pw - 1; len < n; len <<= 1, l -= 1) {
        for (int i = 0; i < n; i += len + len) {
            for (int j = 0; j < len; ++j) {
                int u = a[i+j], v = a[i+j+len] * wp[j << l] % MOD;
                a[i+j] = add(u, v);
                a[i+j+len] = add(u, MOD-v);
            }
        }
    }
}

inline void ifft(int *a, int n) {
    reverse(a + 1, a + n);
    fft(a, n);
    int ni = pmod(n, MOD - 2);
    forn(i, n) a[i] = a[i] * ni % MOD;
}

void pow(int *a, int *out, int deg, int p) {
    int sz = 2 * deg;
    int *temp = out + sz, *cur = out + 2 * sz;
    memset(out, 0, sizeof(int) * 3 * sz);
    out[0] = 1;
    if (p == 1) {
        copy(a, a + deg, out);
        return;
    }
    copy(a, a + deg, cur);
    for (; p; p >>= 1) {
        if (p & 1) {
            fft(out, sz);
            copy(cur, cur + sz, temp);
            fft(temp, sz);
            forn(i, sz) out[i] = out[i] * temp[i] % MOD;
            ifft(out, sz);
            memset(out + deg, 0, sizeof(int) * deg);
        }
        fft(cur, sz);
        forn(i, sz) cur[i] = cur[i] * cur[i] % MOD;
        ifft(cur, sz);
        memset(cur + deg, 0, sizeof(int) * deg);
    }
}

inline void mult(int *a, int *b, int deg) {
    int sz = 2 * deg;
    fft(a, sz);
    fft(b, sz);
    forn(i, sz) a[i] = a[i] * b[i] % MOD;
    ifft(a, sz);
    memset(a + deg, 0, sizeof(int) * deg);
}


const int sz = 1 << root_pw;
const int deg = sz / 2;
int mem[5 * sz];
int *res = mem, *cur = mem + sz, *buf = cur + sz;
int delta = 0, n;
map<pair<int, int>, int> bounds, offset;

inline void remove(int l, int r, int pr) {
    if (pr == 0) return;
    memset(cur, 0, sizeof(int) * sz);
    for (int j = 0; j < deg; j += pr + 1) {
        cur[j] = 1;
        if (j + 1 < deg) cur[j + 1] = MOD - 1;
    }
    pow(cur, buf, deg, r - l + 1);
    mult(res, buf, deg);
}

inline void add(int l, int r, int c) {
    forn(j, sz) cur[j] = j <= c;
    pow(cur, buf, deg, r - l + 1);
    mult(res, buf, deg);
}

inline void update(int l, int r, int C, int D) {
    auto it = bounds.upper_bound(mp(l, -1));
    if (it != bounds.begin()) it = prev(it);
    for (; it != bounds.end(); ) {
        int curl = it->first.first, curr = it->first.second;
        auto nx = next(it);
        if (curl > r) break;
        if (curr < l) { it = nx; continue; }
        int off = offset.at(it->first), pr = it->second;
        offset.erase(it->first);
        bounds.erase(it);
        if (curl < l && curr > r) {
            remove(l, r, pr);
            delta -= off * (r - l + 1);
            bounds.emplace(mp(curl, l - 1), pr);
            offset.emplace(mp(curl, l - 1), off);
            bounds.emplace(mp(r + 1, curr), pr);
            offset.emplace(mp(r + 1, curr), off);
        } else if (curl < l) {
            remove(l, curr, pr); 
            delta -= off * (curr - l + 1);
            bounds.emplace(mp(curl, l - 1), pr);
            offset.emplace(mp(curl, l - 1), off);
        } else if (curr > r) {
            remove(curl, r, pr);
            delta -= off * (r - curl + 1);
            bounds.emplace(mp(r + 1, curr), pr);
            offset.emplace(mp(r + 1, curr), off);
        } else {
            remove(curl, curr, pr);
            delta -= off * (curr - curl + 1);
        }
        it = nx;
    }
    add(l, r, D - C);
    bounds.emplace(mp(l, r), D - C);
    offset.emplace(mp(l, r), C);
    delta += C * (r - l + 1);
}

inline int query(int A) {
    return A >= delta ? res[A - delta] : 0;
}

inline void init() {
    memset(mem, 0, sizeof(int) * sz);
    bounds.clear(), offset.clear();
    forn(i, deg - 10) cur[i] = 1;
    pow(cur, buf, deg, n);
    copy(buf, buf + deg, res);
    delta = 0;
    bounds.emplace(mp(0, n - 1), deg - 11);
    offset.emplace(mp(0, n - 1), 0);
}

void smain() {
    wp[0] = 1;
    for (int i = 1; i < (1 << root_pw); ++i) wp[i] = wp[i - 1] * root % MOD;
    int m, t, l, r, A, C, D;
    for (; cin >> n >> A >> m;) {
        init();
        forn(i, m) {
            cin >> t;
            if (t == 1) {
                cin >> l >> r >> C >> D;
                update(l - 1, r - 1, C, D);
            } else {
                cin >> A;
            }
            cout << query(A) << '\n';
        }
    }
}

