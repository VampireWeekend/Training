#include <iostream>
#include <cstring>
#include <set>
#include <map>
#include <list>
#include <queue>
#include <stack>
#include <bitset>
#define _USE_MATH_DEFINES
#include <math.h>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <assert.h>
#include <stdlib.h>
using namespace std;

void smain();
int main() {
    ios_base::sync_with_stdio(0);
#ifdef TASK
    freopen(TASK".in","rt",stdin);
    const clock_t start = clock();
#endif
    smain();
#ifdef TASK
    cerr << "\nTotal Execution Time: " << float( clock () - start ) /  CLOCKS_PER_SEC << endl;
#endif
    return 0;
}

#ifndef M_PI
#define M_PI 3.14159265358979311599796346854418516
#endif
#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define LL long long
#define int long long
#define mp(a,b) make_pair(a,b)
#define INF 2305843009213693951LL
#define MOD 1000000007
#define EPS 1E-8
#define N 1000
/* --------- END TEMPLATE CODE --------- */


string solve(vector<string> &stripes) {
    int n = stripes.size(), m = stripes.front().size();
    sort(stripes.rbegin(), stripes.rend());
    string res;
    forn(i, n) res.append(stripes[i]);

    forn(i, n) {
        string cur;
        forn(j, n) if (i != j) cur.append(stripes[j]);
        forn(j, m) {
            string pref = stripes[i].substr(0, j);
            string suf = stripes[i].substr(j);
            res = max(res, suf + cur + pref);
        }
    }

    return res;
}

void smain() {
    int n, m;
    for (; cin >> n >> m; ) {
        vector<string> rows(n);
        forn(i, n) cin >> rows[i];
        vector<string> cols(m, string(n, '0'));
        forn(i, m) forn(j, n) cols[i][j] = rows[j][i];

        string res = solve(rows);
        
        res = max(res, solve(cols));
        cout << res << '\n';
    }
}
