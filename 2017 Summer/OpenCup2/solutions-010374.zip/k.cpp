#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <iostream>

using namespace std;

const int MAXSIZE = 131072;
const long long MAXVALUE = 1000000000;

long long arr[MAXSIZE];
int tree[MAXSIZE*2-1];
int lob[MAXSIZE];
int hib[MAXSIZE];
int rows[MAXSIZE];

int w, h;

int min(int i, int j) { return i < j ? i : j; }
int max(int i, int j) { return i > j ? i : j; }

void borders(int column, int& lo, int& hi) {
    lo = lob[column];
    hi = hib[column];
}

int treeindex(int column) {
    return MAXSIZE-1 + column;
}

long long read(int column) {
    return arr[column];
}

void write(int column, long long value) {
    // cout << "write " << value << " @ " << column << endl;

    arr[column] = value;
    int i = treeindex(column);
    tree[i] = column;

    // cout << "index is " << i << endl;

    while (i > 0) {
        i = (i - 1) / 2;
        int j = i*2 + 1, k = j + 1;

        // cout << i << " -> (" << j << "; " << k << ")" << endl;

        if (read(tree[j]) < read(tree[k]))
            tree[i] = tree[j];
        else 
            tree[i] = tree[k];
    }
}

int treemin(int lo, int hi) {
    if (lo == hi) return tree[treeindex(lo)];

    int i = treeindex(lo), j = treeindex(hi);
    int minindex = read(tree[i]) < read(tree[j]) ? tree[i] : tree[j];

    while (j > i+1) {
        if (i%2 == 1) minindex = read(tree[i+1]) < read(minindex) ? tree[i+1] : minindex;
        if (j%2 == 0) minindex = read(tree[j-1]) < read(minindex) ? tree[j-1] : minindex;

        i = (i - 1) / 2;
        j = (j - 1) / 2;
    } 

    return minindex;
}

int where(int column, int lo, int hi) {
    long long minval = read(treemin(lo, hi));

    // cout << "min @ [" << lo << "; " << hi << "] is " << minval << " @ " << treemin(lo, hi) << endl;
    
    int i = -1, j = max(hi - column, column - lo);
    while (j > i+1) {
        int k = (i + j + 1) / 2;
        if (read(treemin(max(lo, column - k), min(hi, column + k))) == minval)
            j = k;
        else 
            i = k;
    }

    // cout << "taken " << j << endl;

    if (read(max(lo, column - j)) == minval)
        return max(lo, column - j);
    return min(hi, column + j);
}

long long down(int column, long long value) {
    long long previous = read(column);
    write(column, value);

    int rowsleft = rows[column];
    // cout << rowsleft << " to top" << endl;
    rows[column]--;

    if (column + rowsleft - 1 < w)
        lob[column + rowsleft - 1] = max(lob[column + rowsleft - 1], column);
    if (column + rowsleft - 1 + 1 < w)
        lob[column + rowsleft - 1 + 1] = max(lob[column + rowsleft - 1 + 1], column + 1);

    if (column - rowsleft + 1 >= 0)
        hib[column - rowsleft + 1] = min(hib[column - rowsleft + 1], column);
    if (column - rowsleft + 1 - 1 >= 0)
        hib[column - rowsleft + 1 - 1] = min(hib[column - rowsleft + 1 - 1], column - 1);

    return previous;
}

int main(void) {
    cin >> w >> h;
    for (int i=0; i<MAXSIZE; i++) tree[treeindex(i)] = i, arr[i] = MAXVALUE+1;
    for (int i=MAXSIZE-1; i>=0; i--) tree[i] = tree[i*2+1];

    long long total = 0;
    for (int i=0; i<w; i++) {
        long long value; cin >> value;
        total += value; write(i, value);

        // cout << "=====" << endl;
        // int count = 1, here = 0; while (count < MAXSIZE*2) {
        //     for (int i=0; i<count; i++, here++)
        //         cout << tree[here] << "(" << read(tree[here]) << ") ";
        //     cout << endl;
        //     count <<= 1;
        // }
        // cout << "=====" << endl;
    }


    for (int i=0; i<w; i++) {
        lob[i] = max(0, i - h); // i - h
        hib[i] = min(w - 1, i + h); // i + h
        rows[i] = h;
    }

    int k; cin >> k; for (int i=0; i<k; i++) {
        int column; long long value;
        cin >> column >> value; column--;

        // cout << "fall from " << column << endl;

        int lo, hi; borders(column, lo, hi);
        int pos = where(column, lo, hi);
        long long previous = down(pos, value);

        // cout << "put " << value << " @ " << pos << " instead of " << previous << " (" << (pos > 0 ? read(pos-1) : '_') << " " << previous << " " << (pos < w-1 ? read(pos+1) : '_') << ")" << endl;

        total += value - previous;

        cout << total << '\n';
    }

    return 0;
} 