#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>

using namespace std;

const double eps = 1e-7;

double myabs(double x) {
    return x > 0 ? x : -x; 
}

bool eq(double x, double y) {
    return myabs(x - y) < eps;
}

bool lt(double x, double y) {
    return x - y < -eps;
}

bool gt(double x, double y) {
    return x - y > eps;
}

int min(int x, int y) {
    return x < y ? x : y;
}

int max(int x, int y) {
    return x > y ? x : y;
}

struct Point {
    double x;
    double y;
    // for cities
    int index;
};

struct Line {
    double a;
    double b;
    double c;
};

// river
Point src, dir;
Line riv;

Line mkline(Point a, Point b) {
    Line l;
    l.a = a.y - b.y;
    l.b = b.x - a.x;
    l.c = l.a * a.x + l.b * a.y;
    return l;
}

Point add(Point b, Point a) {
    Point next;
    next.x = a.x + b.x;
    next.y = a.y + b.y;
    return next; 
}

Point sub(Point dest, Point src) {
    Point next;
    next.x = dest.x - src.x;
    next.y = dest.y - src.y;
    return next;
}

double scal(Point a, Point b) {
    return a.x * b.x + a.y * b.y;
}

long long sqrdist(Point a, Point b) {
    long long dx = a.x - b.x;
    long long dy = a.y - b.y;
    return dx * dx + dy * dy;
}

double dist(Point a, Point b) {
    double dx = a.x - b.x;
    double dy = a.y - b.y;
    return sqrt(dx * dx + dy * dy);
}

double len(Point v) {
    Point zero; zero.x = 0; zero.y = 0;
    return dist(zero, v);
}

Point norm(Point v) {
    double l = len(v);
    Point n; n.x = v.x / l; n.y = v.y / l;
    return n;
}

Point perp(Point v) {
    Point p;
    p.x = v.y; p.y = -v.x;
    return p;
}

bool is(Point a, Point b) {
    return a.index == b.index;
}

bool online(Point p, Point a, Point b) {
    Line l = mkline(a, b);

    double exp = l.a * p.x + l.b * p.y;
    if (!eq(exp, l.c))
        return false;

    if (p.x < min(a.x, b.x) || p.x > max(a.x, b.x)) 
        return false;
    if (p.y < min(a.y, b.y) || p.y > max(a.y, b.y)) 
        return false;

    return true;
}

bool onriver(Point p) {
    // cout << "got onriver" << endl;
    Line l = mkline(src, add(src, dir));

    double exp = l.a * p.x + l.b * p.y;
    // cout << "exp for (" << p.x << ", " << p.y << ") is " << exp << endl;
    if (!eq(exp, l.c))
        return false;

    // cout << "calc scal" << endl;

    Point d = sub(p, src);
    // cout << "p is " << p.x << ", " << p.y << endl;
    // cout << "d is " << d.x << ", " << d.y << endl;

    return scal(dir, d) > eps; 
}

bool onriver(Point* p) {
    return onriver(*p);
}

bool online(Point* p, Point a, Point b) {
    return online(*p, a, b);
}

Point* crossp(Line i, Line j) {
    double denom = i.a * j.b - i.b * j.a;
    if (eq(denom, 0))
        return NULL;

    double x = 1.0 * (i.c * j.b - i.b * j.c) / denom;
    double y = 1.0 * (i.a * j.c - i.c * j.a) / denom;

    // cout << "x @ " << x << ", " << y << endl;

    Point* p = new Point();
    p->x = x;
    p->y = y;

    return p;
}

bool bridge(Point a, Point b) {
    Line seg = mkline(a, b);
    Point* cp = crossp(seg, riv);
    if (cp != NULL)
        return online(cp, a, b) && onriver(cp);
    
    return false;
}

bool cw(Point a, Point b, Point c) {
    return (b.x-a.x)*(c.y-b.y)-(b.y-a.y)*(c.x-b.x) <= 0;
}

bool ccw(Point a, Point b, Point c) {
    return (b.x-a.x)*(c.y-b.y)-(b.y-a.y)*(c.x-b.x) >= 0;
}

vector<Point> cohull(vector<Point> &points) {
    vector<Point> hull;

    vector<Point> tmp;
    vector<Point> up;
    vector<Point> down;

    sort(points.begin(), points.end(), 
        [](Point& i, Point& j) -> 
            bool { return i.x < j.x || i.x == j.x && i.y < j.y; });

    for (int i=0; i<points.size(); i++) {
        while (up.size()>1 && !cw(up[up.size()-2], up[up.size()-1], points[i])) 
            tmp.push_back(up.back()), up.pop_back();
        up.push_back(points[i]);
    }

    tmp.push_back(up.front()), tmp.push_back(up.back());

    sort(tmp.begin(), tmp.end(), 
        [](Point& i, Point& j) -> 
            bool { return i.x < j.x || i.x == j.x && i.y < j.y; });

    points.clear();

    for (int i=0; i<tmp.size(); i++) {
        while (down.size()>1 && !ccw(down[down.size()-2], down[down.size()-1], tmp[i])) 
            points.push_back(down.back()), down.pop_back();
        down.push_back(tmp[i]);
    }

    for (int i=0; i<up.size(); i++) hull.push_back(up[i]);
    for (int i=down.size()-2; i>0; i--) hull.push_back(down[i]);

    return hull;
}

int nosolution() {
    cout << -1; return 0;
}

bool atleft(Point p) {
    return cw(src, add(src, dir), p);
}

void split(vector<Point> all, vector<Point> &lepa, vector<Point> &ripa) {
    for (Point p : all) 
        if (atleft(p))
            lepa.push_back(p);
        else    
            ripa.push_back(p);
}

void ml() {
    new int[99999999999];
}

int find(vector<Point> where, Point what) {
    for (int i=0; i<where.size(); i++)
        if (what.index == where[i].index)
            return i;
    ml();
}

int output(vector<Point> answer, string msg) {
    for (int i=0; i<answer.size(); i++)
        cout 
            << (answer[i].index+1)
            << " " 
            // << " -> " 
            // << answer[i].x << " " 
            // << answer[i].y 
            // << endl
            ;
    // cout << "=== " << msg << " done (" << answer.size() << ")" << endl;
    return 0;
}

vector<Point> pass(Point direction, vector<Point> &points) {
    direction = norm(direction);
    Point perpendicular = perp(direction);

    sort(points.begin(), points.end(),
            // todo: test 
            [direction, perpendicular](Point& i, Point& j) ->
                bool { 
                    double sci = scal(i, direction), scj = scal(j, direction);
                    if (lt(sci, scj)) {
                        // cout << sci << " < " << scj << " -> " << i.index+1 << " < " << j.index+1 << endl; 
                        return true;
                    }
                    if (eq(sci, scj))
                        return lt(scal(i, perpendicular), scal(j, perpendicular));
                    // cout << sci << " > " << scj << " -> " << i.index+1 << " > " << j.index+1 << endl;
                    return false;
                });

    // output(points);
    // cout << "=== pass done" << endl;

    return points;
}

vector<Point> arc(Point src, Point dest, vector<Point> &hull) {
    // output(hull, "hull for arc");
    // build the tail
    // todo: test
    vector<Point> arc;
    vector<Point> other;
    for (int i=0, here=find(hull, src), passed=false; i<hull.size(); i++, here = (here+1)%hull.size()) {
        if (!passed)
            arc.push_back(hull[here]);
        else    
            other.push_back(hull[here]);
        if (!passed)
            if (is(hull[here], dest)) passed = true;
    }

    hull.clear();
    hull.insert(hull.end(), other.begin(), other.end());

    // output(arc, "arc");

    return arc;

}

vector<Point> half3(Point a, Point b, Point furthest, vector<Point> &hull, vector<Point> &others) {
    // cout << "in half 3" << endl;
    // find the "tail"'s head
    // todo: test
    Point btail = furthest, etail = b;
    for (int i=0, here=find(hull, btail); i<hull.size(); i++, here = (here+1)%hull.size())
        if (is(hull[here], a)) {
            btail = b, etail = furthest;
            // cout << "swap!" << endl;
            break;
        } else if (is(hull[here], etail))
            break;

    // cout << "tail head found: " << btail.index+1 << " (" << btail.x << "; " << btail.y << ")" << endl;
    // cout << "tail end  found: " << etail.index+1 << " (" << etail.x << "; " << etail.y << ")" << endl;

    vector<Point> tail = arc(btail, etail, hull);
    if (!is(tail.front(), furthest))
        reverse(tail.begin(), tail.end());
    // output(tail);
    // cout << "=== tail built" << endl;

    // add points from the hull
    others.insert(others.end(), hull.begin(), hull.end());

    others = pass(sub(furthest, a), others);        
    others.insert(others.end(), tail.begin(), tail.end());

    return others;
}

vector<Point> half4(Point a, Point b, Point f0, Point f1, vector<Point> &hull, vector<Point> &others) {
    // output(hull, "hull in half4");
    // output(others, "others in half4");
    vector<Point> got;
    // cout << "a @ " << find(hull, a) << endl;
    for (int i=0, here=find(hull, a); i<hull.size(); i++, here = (here+1)%hull.size())
        if (is(hull[here], a)) {
            got.push_back(a);
        } else if (is(hull[here], b)) {
            got.push_back(b);
        } else if (is(hull[here], f0)) {
            got.push_back(f0);
        } else if (is(hull[here], f1)) {
            got.push_back(f1);
        }

    // output(got, "got");

    vector<Point> tail0, tail1, mid;
    if (is(b, got[2])) {
        // cout << "a * b *" << endl;
        // a, *, b, *
        tail0 = arc(a, got[1], hull);
        tail1 = arc(b, got[3], hull);
        reverse(tail1.begin(), tail1.end());
        others.insert(others.end(), hull.begin(), hull.end());
        mid = pass(sub(got[3], got[1]), others);
    } else if (is(b, got[1])) {
        // cout << "a b * *" << endl;
        // a, b, *, *
        tail0 = arc(got[3], a, hull);
        reverse(tail0.begin(), tail0.end());
        tail1 = arc(b, got[2], hull);
        reverse(tail1.begin(), tail1.end());
        others.insert(others.end(), hull.begin(), hull.end());
        mid = pass(sub(got[2], got[3]), others);
    } else {
        // cout << "a * * b" << endl;
        // a, *, *, b
        tail0 = arc(a, got[1], hull);
        tail1 = arc(got[2], b, hull);
        others.insert(others.end(), hull.begin(), hull.end());
        mid = pass(sub(got[2], got[1]), others);
    }

    // output(tail0, "tail0");
    // output(mid, "mid");
    // output(tail1, "tail1");

    tail0.insert(tail0.end(), mid.begin(), mid.end());
    tail0.insert(tail0.end(), tail1.begin(), tail1.end());

    return tail0;
}

vector<Point> through(vector<Point> points, Point a, Point b) {
    // cout << "in through: " << points.size() << endl;
    // cout << "a is: " << a.index+1 << " (" << a.x << "; " << a.y << ")" << endl;
    // cout << "b is: " << b.index+1 << " (" << b.x << "; " << b.y << ")" << endl;

    if (points.size() == 1) {
        vector<Point> path;
        path.push_back(a);
        // test
        return path;
    }

    if (points.size() == 2) {
        vector<Point> path;
        path.push_back(a);
        path.push_back(b);
        // test
        return path;
    }

    vector<Point> hull = cohull(points);
    // output(hull);
    // cout << "hull found ====" << endl;

    // find the two furthest points
    Point f0 = hull[0], f1 = hull[1];
    long long d = sqrdist(f0, f1);
    for (int i=0; i<hull.size(); i++)
        for (int j=i+1; j<hull.size(); j++) {
            long long dd = sqrdist(hull[i], hull[j]);
            if (dd > d) 
                d = dd, f0 = hull[i], f1 = hull[j];
        }

    // cout << "furthest found: " << f0.index+1 << " (" << f0.x << "; " << f0.y << "), " << f1.index+1 << " (" << f1.x << "; " << f1.y << ")" << endl;

    if (is(f0, a))
        return half3(a, b, f1, hull, points);
    else if (is(f1, a))
        return half3(a, b, f0, hull, points);
    else if (is(f0, b)) {
        vector<Point> solution = half3(b, a, f1, hull, points);
        reverse(solution.begin(), solution.end());
        return solution;
    } else if (is(f1, b)) {
        vector<Point> solution = half3(b, a, f0, hull, points);
        reverse(solution.begin(), solution.end());
        return solution;
    } else  
        return half4(a, b, f0, f1, hull, points);
}

bool findEdge(vector<Point> points, Point& le, Point &ri) {
    vector<Point> hu = cohull(points);

    // output(inner, "inner");

    for (int i=0, K=hu.size(); i<K; i++) {
        int j = i<K-1 ? i+1 : 0;
        Point a = hu[i], b = hu[j];
        if (!atleft(a) || atleft(b))
            continue;
        // cannot be a == le0, b == ri0

        // cout << "check (" << a.x << "; " << a.y << ") -> (" << b.x << "; " << b.y << ")" << endl;

        Line seg = mkline(a, b);
        Point* cp = crossp(seg, riv);
        if (cp != NULL) {
            // cout << "cp is (" << cp->x << "; " << cp->y << ")" << endl;
            if (online(cp, a, b)) 
                if (!bridge(a, b)) {
                    // cout << "found!!!" << endl; 
                    ri = b, le = a;
                } else
                    return false; 
        }
    }

    return true;
}

int main(void) {
    int N; cin >> N;

    cin >> src.x >> src.y;
    cin >> dir.x >> dir.y;
    riv = mkline(src, add(src, dir));

    vector<Point> cities;
    for (int i=0; i<N; i++) {
        Point city; 
        city.index = i;
        cin >> city.x >> city.y; cities.push_back(city);
    }

    // output(cities);
    // cout << "cities done ====" << endl;

    vector<Point> hull = cohull(cities);

    // find a break-point in the convex hull
    Point le0, ri0; 
    // cout << riv.a << "; " << riv.b << " = " << riv.c << endl;
    for (int i=0, found=0, K=hull.size(); i<K; i++) {
        int j = i<K-1 ? i+1 : 0;

        if (bridge(hull[i], hull[j]))
            // cout << ">> " << i << "-> " << j 
            //     << ": (" << a.x << "; " << a.y << ") -> (" << b.x << "; " << b.y << ")" 
            //     << " crosses river @ " << cp->x << " " << cp->y << endl;
            if (!found)
                ri0 = hull[i], le0 = hull[j], found = true;
            else 
                return nosolution();
    }

    // output(hull, "hull");

    // cout << "le0 is " << le0.index+1 << " (" << le0.x << "; " << le0.y << ")" << endl;
    // cout << "ri0 is " << ri0.index+1 << " (" << ri0.x << "; " << ri0.y << ")" << endl;

    // cout << "le0, ri0 found" << endl;

    vector<Point> answer;
    // -1 to exclude ri0 (it's in the ripath)
    for (int i=0, here=find(hull, le0); i<hull.size()-1; i++, here=(here+1)%hull.size())
        answer.push_back(hull[here]);
    // output(answer);
    // cout << "pre-answer done ===" << endl;

    if (0 == cities.size())
        // todo: test
        return nosolution();

    if (1 == cities.size()) {
        Point c = cities[0];
        if (bridge(le0, c) || bridge(c, ri0))
            // todo: test
            return nosolution();

        answer.push_back(ri0);
        answer.push_back(c);
        answer.push_back(le0);
        // todo: test
        return output(answer, "answer");
    }

    if (2 == cities.size()) {
        Point c = cities[0], d = cities[1];

        if (!bridge(le0, c) && !bridge(c, d) && !bridge(d, ri0)) {
            answer.push_back(ri0);
            answer.push_back(d);
            answer.push_back(c);
            answer.push_back(le0);
            // todo: test
            return output(answer, "answer");
        }

        if (!bridge(ri0, c) && !bridge(c, d) && !bridge(d, le0)) {
            answer.push_back(ri0);
            answer.push_back(c);
            answer.push_back(d);
            answer.push_back(le0);
            // todo: test
            return output(answer, "answer");
        }

        return nosolution();
    }

    Point le1, ri1;
    bool found = findEdge(cities, le1, ri1); 

    cities.push_back(le0);
    cities.push_back(ri0);

    if (!found)
        if (!findEdge(cities, le1, ri1))
            return nosolution();

    // output(cities, "=== cities");

    // cout << "le1 is " << le1.index+1 << " (" << le1.x << "; " << le1.y << ")" << endl;
    // cout << "ri1 is " << ri1.index+1 << " (" << ri1.x << "; " << ri1.y << ")" << endl;

    // cout << "le1, ri1 found" << endl;

    // put back inner into cities
    // cities.insert(cities.end(), inner.begin(), inner.end());

    vector<Point> lepa, ripa;
    // todo: test
    split(cities, lepa, ripa);
    // cout << "split done: " <<  cities.size() << " -> " << lepa.size() << "/" << ripa.size() << endl;
    // output(lepa, "lepa");
    // output(ripa, "ripa");

    if (is(le0, le1) && lepa.size() > 1)
        return nosolution();
    if (is(ri0, ri1) && ripa.size() > 1)
        return nosolution();

    // cout << "search 4 lepath" << endl;
    vector<Point> lepath = through(lepa, le0, le1);
    // output(lepath, "lepath");
    vector<Point> ripath = through(ripa, ri0, ri1);
    // output(ripath, "ripath");

    // build the answer
    // todo: test
    answer.insert(answer.end(), ripath.begin(), ripath.end());
    // left path must be in the reverse order
    reverse(lepath.begin(), lepath.end());
    answer.insert(answer.end(), lepath.begin(), lepath.end());

    return output(answer, "answer");
}