#include <iostream>

using namespace std;

enum RC { ROW, COL };

struct V {
    RC rc;
    int coord;
};

int n, m;
string* map;
bool* flag;
V* queue;
int pb = 0, pe = 0;
int cg = 0;
int* groups;
int* color;

bool empty() {
    return pb == pe; 
}

bool visited(V v) {
    return flag[v.rc == ROW ? v.coord : n + v.coord];
}

V remove() {
    return queue[pb++];
}

int count(V v) {
    if (v.rc == ROW) return 0;

    int result = 0;
    for (int r=0; r<n; r++)
        if ('.' != map[r][v.coord])
            result++;

    return result;
}

void visit(V v) {
    flag[v.rc == ROW ? v.coord : n + v.coord] = true;
    color[v.rc == ROW ? v.coord : n + v.coord] = cg;

    if (v.rc == COL) 
        groups[cg] += count(v);
}

void push(V v) {
    if (visited(v)) return;

    visit(v);
    queue[pe++] = v;
}

V make(RC rc, int coord) {
    V v;
    v.rc = rc;
    v.coord = coord;
    return v;
}

void bfs(V v) {
    pb = pe = 0;
    push(v);

    while (!empty()) {
        V here = remove();
        for (int i = 0; i < (here.rc == COL ? n : m); i++) {
            char edge = here.rc == COL ? map[i][here.coord] : map[here.coord][i];
            if ('.' != edge)
                push(make(here.rc == COL ? ROW : COL, i));
        }
    }
}

int main(void) {
    cin >> n >> m;
    
    map = new string[n];
    queue = new V[n + m];
    flag = new bool[n + m];
    color = new int[n + m];
    groups = new int[m];

    for (int i=0; i<n; i++) cin >> map[i];

    for (int i=0; i<n+m; i++) {
        flag[i] = false;
        color[i] = -1;
        if (i < m) groups[i] = 0;
    }

    for (int c=0; c<m; c++, cg++) 
        bfs(make(COL, c));

    int answer = 0, ra = 0, rc = 0;

    for (int r=0; r<n; r++)
        for (int c=0; c<m; c++) if (color[n + c] > -1)
            if ('.' == map[r][c]) {
                int count = groups[color[n + c]];
                if (color[r] > -1 && color[r] != color[n + c])
                    count += groups[color[r]];
                if (count > answer) {
                    answer = count; ra = r; rc = c;
                }
            }

    cout << answer << endl;
    if (answer > 0) 
        cout << ra+1 << " " << rc+1;

    return 0;
}