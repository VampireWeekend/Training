#include <stdio.h>
#include <iostream>
#include <cstring>
#include <set>
#include <map>
#include <list>
#include <queue>
#include <stack>
#include <bitset>
#define _USE_MATH_DEFINES
#include <math.h>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <assert.h>
using namespace std;

void smain();
int main(){
    ios_base::sync_with_stdio(0);
#ifdef TASK
    freopen(TASK".in","rt",stdin);
    const clock_t start = clock();
#endif
    cout.precision(12); cout << fixed;
    smain();
#ifdef TASK
    cerr << "\nTotal Execution Time: " << float( clock () - start ) /  CLOCKS_PER_SEC << endl;
#endif
    return 0;
}

#ifndef M_PI
#define M_PI 3.14159265358979311599796346854418516
#endif
#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define LL __int128
#define mp(a,b) make_pair(a,b)
#define INF 2000000000 //2305843009213693951LL
#define MOD 1000000007
#define EPS 1E-9
#define N 600603
/* --------- END TEMPLATE CODE --------- */
string a[N];
unsigned char s[N];
int p[N], c[N], pn[N], cnt[N], cn[N], lcp[N];
vector<int> edges[N];
int mt[N];
bool used[N];

bool dfs(int v) {
    if (used[v]) return false;
    used[v] = true;
    for (auto i : edges[v]) {
        if (mt[i] == -1 || dfs(mt[i])) {
            mt[i] = v;
            return true;
        }
    }
    return false;
}

int matching(int n, int m) {
    memset(mt, 255, sizeof(int) * m);
    memset(used, 0, n);
    forn(i, n) if (dfs(i)) memset(used, 0, n);
    
    int res = 0;
    forn(i, m) if (mt[i] != -1) res += 1;
    return res;
}

void suffix_array(int n) {
    memset(cnt, 0, sizeof(int) * 256);
    forn(i, n) cnt[(int)s[i]] += 1;
    forn(i, 256) cnt[i + 1] += cnt[i];
    forn(i, n) p[--cnt[(int)s[i]]] = i;
    c[p[0]] = 0;
    int m = 1;
    for (int i = 1; i < n; ++i) {
        if (s[p[i]] != s[p[i-1]]) m += 1;
        c[p[i]] = m - 1;
    }

    for (int len = 1; len < n; len <<= 1) {
        forn(i, n) {
            pn[i] = p[i] - len;
            if (pn[i] < 0) pn[i] += n;
        }
        memset(cnt, 0, sizeof(int) * m);
        forn(i, n) cnt[c[pn[i]]] += 1;
        forn(i, m - 1) cnt[i + 1] += cnt[i];
        rforn(i, n) p[--cnt[c[pn[i]]]] = pn[i];
        cn[p[0]] = 0;
        m = 1;
        for (int i = 1; i < n; ++i) {
            int mid1 = (p[i] + len) % n, mid2 = (p[i-1] + len) % n;
            if (c[p[i]] != c[p[i-1]] || c[mid1] != c[mid2]) m += 1;
            cn[p[i]] = m - 1;
        }
        memcpy(c, cn, n * sizeof(int));
    }
}

void build_lcp(int n) {
    forn(i, n) c[p[i]] = i;
    int k = 0;
    forn(i, n) {
        if (k > 0) k -= 1;
        if (c[i] == n - 1) {
            k = 0;
        } else {
            int j = p[c[i] + 1];
            while (max(i + k, j + k) < n && s[i + k] == s[j + k]) k += 1;
            lcp[c[i]] = k;
        }
    }
}

int solve(int n) {
    int k = 0;
    vector<int> pos(n);
    vector<int> len(n);
    forn(i, n) {
        pos[i] = k;
        len[i] = i ? len[i-1] + a[i-1].length() : 0;
        for (auto j : a[i]) s[k++] = j - 'a';
        for (auto j : a[i]) s[k++] = j - 'a';
        s[k++] = i + 26;
    }
    
    suffix_array(k);
    build_lcp(k);
    
    int m = 0, pr = a[0].length();
    forn(i, k) {
        size_t j = upper_bound(pos.begin(), pos.end(), p[i]) - pos.begin() - 1;
        if (p[i] >= pos[j] + (int)a[j].length()) {
            pr = min(pr, lcp[i]);
            continue;
        }
        int nx = lcp[i];
        lcp[m] = pr, pn[m] = j, p[m++] = p[i] - pos[j] + len[j];
        pr = nx;
    }

    int l = 1, r = a[0].length();
    forn(i, n) r = max(r, (int)a[i].length());
    while (l < r) {
        int x = (l + r) / 2;
        forn(i, n) edges[i].clear();
        int v = 0, small = 0; 
        forn(i, m) {
            if (lcp[i] < x) v = i;
            edges[pn[i]].push_back(v);
        }
        forn(i, n) if ((int)a[i].length() < x) small += 1, edges[i].clear(); 
        int t = matching(n, m) + small;
        if (t == n) r = x;
        else l = x + 1;
    }

    return l;
}

void smain() {
    for (int n; cin >> n; ) {
        forn(i, n) cin >> a[i];
        cout << solve(n) << endl;
    }
}
