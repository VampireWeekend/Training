#include <iostream>

using namespace std;

const int INFINITY = 1000000;

// persons
int n;
// groups
int m;
// capacity of the bus
int k;

struct Group {
    int size;
    long long time;
};

long long solve(Group* groups) {
    long long* x = new long long[n + 1];
    for (int i=0; i<n+1; i++) x[i] = INFINITY;
    x[0] = 0;

    // all groups but the last; the last always goes
    // into "last" bus
    for (int i=0; i<m-1; i++)
        for (int j=n-groups[i].size; j>=0; j--) {
            long long time = max(x[j], groups[i].time);
            x[j+groups[i].size] = min(time, x[j+groups[i].size]);
        }

    //for (int i=0; i<=n; i++) cout << x[i] << " ";
    //cout << endl;

    long long answer = -1;
    for (int i=0; i<=k; i++) 
        if (n - i <= k) if (x[i] < INFINITY) {
            long long total = x[i] * i + (n - i) * groups[m-1].time;
            if (answer == -1 || total < answer)
                answer = total;
        }
    
    return answer;
}

int main(void) {
    cin >> n >> m >> k;

    Group* groups = new Group[m];
    for (int i=0; i<m; i++) groups[i].size = 0;
    for (int i=0; i<n; i++) {
        int j; cin >> j; j--;
        groups[j].size++;
        groups[j].time = i+1;
    }

    int j = 0; for (int i=1; i<m; i++)
        if (groups[i].time > groups[j].time)
            j = i;
    Group t = groups[j]; groups[j] = groups[m-1]; groups[m-1] = t;

    //for (int i=0; i<m; i++) cout << "size: " << groups[i].size << ", time: " << groups[i].time << endl;

    cout << solve(groups);

    return 0;
}