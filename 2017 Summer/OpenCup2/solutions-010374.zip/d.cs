using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Koscheys
{
	class Koscheys
	{
		static void Main(string[] args)
		{
			string rooms = Console.ReadLine();
			var N = rooms.Length;
			var i = 0;
			var ans = 0;
			var hats = 0;
			var money = 0;
			while (i < N)
			{
				if (rooms[i] == 'H')
					hats++;
				else if (rooms[i] == 'M')
					money++;
				else if (rooms[i] == 'K')
				{
					if (hats > 0)
					{
						hats--;
					}
					else
					{
						if (money > ans)
							ans = money;
						money = 0;
					}
				}
				else
				{
					throw new ArgumentException();
				}
				i++;
			}
			if (money > ans)
				ans = money;
			Console.WriteLine(ans);
		}
	}
}
